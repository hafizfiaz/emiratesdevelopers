# -*- coding: utf-8 -*-


{
    'name': "SD Accounting Workflow Inherit",

    'summary': """Accounting Workflow Inherit""",

    'description': """
    """,

    'author': "Muhammad Usman Zameer",
    'website': "http://www.yourcompany.com",
    'category': 'Test',
    'version': '0.1',
    'depends': ['base', 'sale', 'account_pdc','settlement','spa_customizations'],
    'data': [
        'views/view.xml',
        # 'views/email.xml',
    ],
    'demo': [],
}
